# CGT_CW1
Stackelberg game in python 
